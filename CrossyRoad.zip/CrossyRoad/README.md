Crossy Road 

Description
-------------------
This is the popular mobile game Crossy Road recreated using Unreal Engine. Not all of the original mechanics of the game are there such as eagles but the core gameplay mechanics are implemented.


Controls
--------------------
WASD - up, down, left, right movement of Chicken
